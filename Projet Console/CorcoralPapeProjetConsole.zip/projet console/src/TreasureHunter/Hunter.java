package TreasureHunter;

public class Hunter extends Entity
{
	
	private int dir;
	private int treasureX, treasureY;

	public Hunter(int x, int y, String sym, int tX, int tY) 
	{
		super(x,y,sym);
		this.dir = initDir();
		this.treasureX = tX;
		this.treasureY = tY;
	}
	
	private int initDir()
	{
		return (int) (1 + (Math.random() * (8-1)));
	}
	
	/**
	 * getters
	 */
	/**
	 * @return	int 	Coordon�e en x du tr�sor
	 */
	public int getTreasureX() {return this.treasureX;}
	/**
	 * @return 	int		Coordon� en y du tr�sor
	 */
	public int getTreasureY() {return this.treasureY;}
	/**
	 * 
	 * @return	int 	Direction du chasseur
	 */
	public int getDir(){return dir;}
	/**
	 * 
	 * @param dim	int 	dimension du plateau de jeu
	 * @return		int 	indice du chasseur dans la liste de cases
	 */
	public int getindice(int dim) {return dim * this.getY() + this.getX();}
	
	/**
	 * setter
	 */
	
	/**
	 * @param newDir	int		nouvelle direction � d�finir
	 */
	public void setDir(int newDir) {this.dir = newDir;}
	
	/**
	 * Renvoie l'indice de la future case du chasseur en fonction de sa direction
	 * 
	 * @param 		int 	dim		taille du plateau
	 * @return		int 	future indice
	 */
	public int moveHunter(int dim)
	{
		int res = 0;
		switch(this.dir)
		{
			case 1 : res = (dim+2) * this.getY() + (this.getX()+1);
				     System.out.println("    Case cible : " + (this.getX()+1) + " " + this.getY() );
				break;
			case 2 : res = (dim+2) * (this.getY()-1) + (this.getX()+1);
					System.out.println("    Case cible : " + (this.getX()+1) + " " + (this.getY()-1) );
				break;
			case 3 : res = (dim+2) * (this.getY()-1) + this.getX();
		     		System.out.println("    Case cible : " + this.getX() + " " + (this.getY()-1) );
				break;
			case 4 : res = (dim+2) * (this.getY()-1) + (this.getX()-1);
					System.out.println("    Case cible : " + (this.getX()-1) + " " + (this.getY()-1) );
				break;
			case 5 : res = (dim+2) * this.getY() + (this.getX()-1);
					System.out.println("    Case cible : " + (this.getX()-1) + " " + this.getY() );
				break;
			case 6 : res = (dim+2) * (this.getY()+1) + (this.getX()-1);
	     			System.out.println("    Case cible : " + (this.getX()-1) + " " + (this.getY()+1) );
				break;
			case 7 : res = (dim+2) * (this.getY()+1) + this.getX();
		     		System.out.println("    Case cible : " + this.getX() + " " + (this.getY()+1) );
				break;
			case 8 : res = (dim+2) * (this.getY()+1) + (this.getX()+1);
		     		System.out.println("    Case cible : " + (this.getX()+1) + " " + (this.getY()+1) );
				break;
		}
		return res;
	}
}

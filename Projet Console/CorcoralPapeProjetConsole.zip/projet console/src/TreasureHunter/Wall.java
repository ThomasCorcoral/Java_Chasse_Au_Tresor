package TreasureHunter;

import java.util.LinkedList;
import java.util.List;

import PlateauDeJeu.Case;

public class Wall 
{
	private List<Case> mur;
	private int size;
	
	/**
	 * Cr�ation d'un mur � l'aide des param�tres d�termin�s dans la classe Board
	 * 
	 * @param dir		int		direction du mur
	 * @param size		int 	taille du mur
	 * @param xInit		int 	x de la premi�re case
	 * @param yInit		int 	y de la premi�re case
	 */
	public Wall(int dir, int size, int xInit, int yInit) 	//			  4
	{														// dir :   3  #  1
		this.size = size;									//			  2
		mur = new LinkedList<Case>();
		
		if(dir == 4 || dir == 3)
		{
			if(dir == 4) // haut
			{	
				for(int y = yInit; y > (yInit - size); y--)
				{
					mur.add(new Stone(xInit , y , xInit , yInit, xInit, yInit-size+1));
					//System.out.println(" MUR : x :" + x_init + " / y : " + y );
				}
			//	System.out.println(" MUR : x :" + x_init + " / y : " + y_init + " / x max : " + x_init + " / y max : " + (y_init-size+1));
			}
			else	// gauche
			{
				for(int x = xInit; x > (xInit - size); x--)
				{
					mur.add(new Stone(x,yInit , xInit , yInit, xInit - size+1 , yInit));
					//System.out.println(" MUR : x :" + x + " / y : " + y_init );
				}
				//System.out.println(" MUR : x :" + x_init + " / y : " + y_init + " / x max : " + (x_init-size+1) + " / y max : " + y_init);
			}
		}
		else
		{
			if(dir == 2)	// bas
			{
				for(int y = yInit; y < (yInit + size); y++)
				{
					mur.add(new Stone(xInit,y , xInit , xInit, xInit, yInit+size-1));
					//System.out.println(" MUR : x :" + x_init + " / y : " + y );
				}
				//System.out.println(" MUR : x :" + x_init + " / y : " + y_init + " / x max : " + x_init + " / y max : " + (y_init+size-1));
			}
			else		// droite
			{
				for(int x = xInit; x < (xInit + size); x++)
				{
					mur.add(new Stone(x,yInit, xInit , yInit, xInit + size - 1, yInit));
					//System.out.println(" MUR : x :" + x_init + " / y : " + y_init + " / x max : " + (x_init+size-1) + " / y max : " + y_init);
				}
				//System.out.println(" MUR : x :" + x_init + " / y : " + y_init + " / x max : " + (x_init+size-1) + " / y max : " + y_init);
			}
		}
		
	}
	
	/**
	 * getters
	 */
	public int getSize() {return this.size;}
	public Case getCase(int i) {return mur.get(i);}
	public int getIndice(int i, int dim) {return dim * mur.get(i).getY() + mur.get(i).getX();}

}

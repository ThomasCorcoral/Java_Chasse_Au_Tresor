package TreasureHunter;

import PlateauDeJeu.Case;

public class Stone extends Case
{
	
	private int xStart, yStart, xEnd, yEnd;

	public Stone(int x, int y, int xSt, int ySt, int xEnd, int yEnd) 
	{
		super(x,y,"#");
		this.xStart = xSt;
		this.yStart = ySt;
		this.xEnd = xEnd;
		this.yEnd = yEnd;
	}

	@Override
	public void process(Hunter h) 
	{
		// Le joueur va rencontrer une pierre et donc un mur qu'il va falloir contourner 
		if(h.getX() == this.xEnd)	// Si le Joueur se situe � la position repr�sent� par la limite en x du mur
		{
			if((this.xStart - this.xEnd) > 0) // le joueur se trouve � gauche
			{
				if(h.getY() < this.getY()) // au dessus
				{
					h.setDir(6);
				}
				else
				{
					h.setDir(4);
				}
			}
			else // le joueur se trouve � droite
			{
				if(h.getY() < this.getY()) // au dessus
				{
					h.setDir(8);
				}
				else
				{
					h.setDir(2);
				}
			}
		}
		else if(h.getX() == this.xStart) // Si le Joueur se situe � la position repr�sent� par le d�but en x du mur
		{
			if((this.xStart - this.xEnd) < 0) // le joueur se trouve � gauche
			{
				if(h.getY() < this.getY()) // au dessus
				{
					h.setDir(6);
				}
				else
				{
					h.setDir(4);
				}
			}
			else // le joueur se trouve � droite
			{
				if(h.getY() < this.getY()) // au dessus
				{
					h.setDir(8);
				}
				else
				{
					h.setDir(2);
				}
			}
		}
		else if(h.getY() == this.yEnd) // Si le Joueur se situe � la position repr�sent� par la limite en y du mur
		{
			if((this.yStart - this.yEnd) > 0) // le joueur se trouve en haut
			{
				if(h.getX() < this.getX())	// � gauche 
				{
					h.setDir(2);
				}
				else // � droite
				{
					h.setDir(4);
				}
			}
			else // le joueur se trouve en bas
			{
				if(h.getX() < this.getX())	// � gauche 
				{
					h.setDir(8);
				}
				else // � droite
				{
					h.setDir(6);
				}
			}
		}
		else if(h.getY() == this.yStart) // Si le Joueur se situe � la position repr�sent� par le d�but en y du mur
		{
			if((this.yStart - this.yEnd) < 0) // le joueur se trouve en haut
			{
				if(h.getX() < this.getX())	// � gauche 
				{
					h.setDir(2);
				}
				else // � droite
				{
					h.setDir(4);
				}
			}
			else // le joueur se trouve en bas
			{
				if(h.getX() < this.getX())	// � gauche 
				{
					h.setDir(8);
				}
				else // � droite
				{
					h.setDir(6);
				}
			}
		}
		else if(this.xStart == this.xEnd) 	// Mur vertical
		{
			// distance en passant par y_start
			int sol1 = (int) ( Math.pow (Math.abs(this.yStart - h.getY()), 2) + 
						( Math.pow (Math.abs(this.yStart - h.getTreasureY() ) , 2) + Math.pow( Math.abs(h.getX() - h.getTreasureX()) , 2)));
		
			// distance en passant par y_end
			int sol2 = (int) ( Math.pow (Math.abs(this.yEnd - h.getY()), 2) +
						( Math.pow (Math.abs(this.yEnd - h.getTreasureY() ) , 2) + Math.pow( Math.abs(h.getX() - h.getTreasureX()) , 2)));
			
			if(sol1 < sol2) // on passe par y_start
			{
				if(yStart < h.getY()) // si la destination (y_start) est au dessus 
				{
					h.setDir(3);
				}
				else
				{
					h.setDir(7);
				}
			}
			else // on passe par y_end
			{
				if(yEnd < h.getY()) // si la destination (y_end) est au dessus 
				{
					h.setDir(3);
				}
				else
				{
					h.setDir(7);
				}
			}
		}
		else		// Mur horizontal
		{
			// distance en passant par x_start
			int sol1 = (int) ( Math.pow (Math.abs(this.xStart - h.getX()), 2) + 
						( Math.pow (Math.abs(this.xStart - h.getTreasureX() ) , 2) + Math.pow( Math.abs(h.getY() - h.getTreasureY()) , 2)));
			
			// distance en passant par y_start
			int sol2 = (int) ( Math.pow (Math.abs(this.xEnd - h.getX()), 2) +
						( Math.pow (Math.abs(this.xEnd - h.getTreasureX() ) , 2) + Math.pow( Math.abs(h.getY() - h.getTreasureY()) , 2)));
			
			if(sol1 < sol2) // on passe par x_start
			{
				if(xStart < h.getX()) // si la destination (x_start) est � gauche 
				{
					h.setDir(5);
				}
				else // si la destination (x_start) est � droite 
				{
					h.setDir(1);
				}
			}
			else
			{
				if(xEnd < h.getX()) // si la destination (x_end) est � gauche
				{
					h.setDir(5);
				}
				else // si la destination (x_end) est � droite 
				{
					h.setDir(1);
				}
			}
		}
	}
}

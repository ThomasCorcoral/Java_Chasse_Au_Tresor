package TreasureHunter;

import PlateauDeJeu.Case;

public class Side extends Case
{

	public Side(int x, int y) 
	{
		super(x,y,"+");
	}

	@Override
	public void process(Hunter h) 
	{
		// Ici, le joueur va taper dans un mur et de ce fait, on va le renvoyer dans la direction oppos�e
		int localDir = h.getDir();
		if(localDir == 4)
		{
			h.setDir(8);
		}
		else
		{
			h.setDir((localDir + 4) % 8);
		}
	}

}

package TreasureHunter;

import PlateauDeJeu.Case;

public class OccupiedByHunter extends Case
{

	public OccupiedByHunter(int x, int y, String nom) 
	{
		super(x,y,nom);
	}

	@Override
	public void process(Hunter h) 
	{
		// nouvelle direction al�atoire diff�rente de la direction actuelle
		int newDir = h.getDir();
		do
		{
			newDir = (int) (1 + (Math.random() * (8-1)));
		}while(newDir == h.getDir());
		
		h.setDir(newDir);
	}

}

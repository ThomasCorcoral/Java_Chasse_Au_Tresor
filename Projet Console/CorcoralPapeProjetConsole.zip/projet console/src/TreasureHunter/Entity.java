package TreasureHunter;

public class Entity 
{
	
	private int x;
	private int y;
	private String symbole;

	public Entity(int x, int y, String sym) 
	{
		this.x = x;
		this.y = y;
		this.symbole = sym;
	}
	
	/**
	 *  getters
	 */
	/**
	 * @return 	int		Coordon�e en y
	 */
	public int getY() {return this.y;}
	/**
	 * @return	int		Coordon�e en x
	 */
	public int getX() {return this.x;}
	
	/**
	 * 	setters
	 */
	/**
	 * 
	 * @param 	x	x � d�finir
	 */
	public void setX(int x) {this.x = x;}
	/**
	 * 
	 * @param 	y	y � d�finir
	 */
	public void setY(int y) {this.y = y;}
	
	/**
	 * @return		String 		Symbole de la case
	 */
	public String toString()
	{
		return this.symbole;
	}
	
}

package TreasureHunter;

public interface Questionnable 
{
	public void process (Hunter h);
	// la case modifie le personnage h
	// un message est affich� � la console pour expliciter
	// la(les) modification(s) du personnage
}
package TreasureHunter;

import java.util.LinkedList;
import java.util.List;

import PlateauDeJeu.Case;

public class Free extends Case 
{

	public Free(int x, int y) 
	{
		super(x,y,".");
	}

	@Override
	public void process(Hunter h) 
	{
		h.setX(this.getX());
		h.setY(this.getY());
		
		int xTresor = h.getTreasureX();
		int yTresor = h.getTreasureY();
		
		// Distance entre le chasseur et le tresor 
		int save = (int) (Math.pow( Math.abs(h.getX() - xTresor) , 2) + Math.pow( Math.abs(h.getY() - yTresor) , 2));
		
		//System.out.println("Cible : FREE"); /* DEBUG */
		
		if(save != 0)
		{
			int localCount = 0;
			int indice = 0;
			
			// Tableau avec les nouvelles direction, cette derni�re sera choisit en fonction de la 
			// distance qui se trouve entre le chasseur et le tr�sor
			List<Integer> direction = new LinkedList<Integer>();
			init_liste(direction);
			
			for(int y = this.getY()-1; y < this.getY()+2; y++)
			{
				for(int x = this.getX()-1; x < this.getX()+2; x++)
				{
					// Si la distance est plus courte alors on stocke l'indice pour la direction future
					if(((int) (Math.pow( Math.abs(x - xTresor) , 2) + Math.pow( Math.abs(y - yTresor) , 2))) < save)
					{
						save = (int) (Math.pow( Math.abs(x - xTresor) , 2) + Math.pow( Math.abs(y - yTresor) , 2));
						indice = localCount;
					}
					localCount++;
				}
			}
			// on prend la future direction dans le tableau
			h.setDir(direction.get(indice));
		}
		else
		{
			// Si l'utilisateur a gagn�, on neutralise la direction
			h.setDir(-1);
		}
	}
	
	public void init_liste(List<Integer> liste)
	{
		liste.add(4);
		liste.add(3);
		liste.add(2);
		liste.add(5);
		liste.add(0);	// Valeur normalement jamais utilis�e
		liste.add(1);
		liste.add(6);
		liste.add(7);
		liste.add(8);
	}

}

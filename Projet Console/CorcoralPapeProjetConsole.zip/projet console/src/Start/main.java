package Start;
import PlateauDeJeu.*;
//import TreasureHunter.*;


public class main 
{
	
	public static void main(String[] args) 
	{
		final int LIMIT_WALL = 3;		// Nombre de murs maximum
		final int LIMIT_HUNTER = 2;		// Nombre de chasseurs
		
		Board plateau = new Board();	// Cr�ation du plateau de jeu
		plateau.initCases();			// Initialisation du plateau
		
		int i = 0;
		while(i < LIMIT_WALL)
		{
			plateau.initWall();		// on initialise un nouveau mur
			plateau.syncWalls();		// Synchronisation de ce mur, on l'int�gre dans le plateau
			i++;
		}
		
		i = 0;
		plateau.initTreasure();		// On positionne le tr�sor
		
		while(i < LIMIT_HUNTER)
		{
			plateau.initHunters();		// Cr�ation d'un nouveau chasseur
			plateau.hunterSync();		// Synchronisation de ce chasseur avec le plateau
			i++;
		}
		
		/*
		 * DEBUG
		 * Test aucun bug / toujours un gagnant
		 
		int cmpt = 0;
		while(cmpt < LIMIT)
		{
			cmpt = 0;
			while(plateau.playTurn() == 0 && cmpt < LIMIT)
			{
				cmpt++;
				System.out.println(plateau.toString());
			}
		}*/
			
		while(plateau.playTurn() == 0)	//	tant que personne n'a gagn�, on joue un nouveau tour
		{
			System.out.println(plateau.toString());		// affichage du plateau
		}
	}

}

package PlateauDeJeu;

import java.util.*;

import TreasureHunter.Hunter;
import TreasureHunter.Treasure;
import TreasureHunter.Wall;
import TreasureHunter.Side;
import TreasureHunter.OccupiedByHunter;
import TreasureHunter.Free;

public class Board 
{
	final int LIMIT_WALL = 100;
	
	private List<Case> plateau;			// Plateau de jeu compos� de cases
	private List<Hunter> joueurs;		// Liste des joueurs
	private List<Wall> murs;			// liste de murs eux m�me compos�s de pierres
	private Treasure tresor;			// Tr�sor � trouver
	private int dim;					// Dimensions du plateau dim x dim (les bordures ne sont pas comprises dans ces dimensions)

	public Board(int dim)
	{
		this.dim = dim;
		plateau = new LinkedList<Case>();
		joueurs = new LinkedList<Hunter>();
		murs = new LinkedList<Wall>();
	}
	
	public Board()
	{
		this(10);		// Si pas de dimension donn�, on initialise � 10
	}
	
	/**
	 * Initialisation des cases du plateau. On le parcoure de gauche � 
	 * droite et de haut en bas. On cr�e des cases vides au milieu et 
	 * des cases correspondant � des bordures
	 */
	public void initCases()
	{
		for(int y = 0; y < this.dim+2; y++)
		{
			for(int x = 0; x < this.dim+2; x++)
			{
				if(x == 0 || x == this.dim+1 || y == 0 || y == this.dim+1) // S'il s'agit d'une bordure
				{
					plateau.add(new Side(x,y));
				}
				else
				{
					plateau.add(new Free(x,y));
				}
			}
		}
	}
	
	/**
	 * Initialisation d'un mur. Pour ce faire un mur va �tre compos�
	 * d'un x et d'un y initiaux. D'une taille et d'une direction
	 */
	public void initWall()			//			  4
	{								// dir :   3  #  1
									//			  2
		int limit = 0;
		int randX;
		int randY;
		
		do	//Recherche du point de d�part initial du mur
		{
			randX = (int) (2 + (Math.random() * (this.dim-2)));
			randY = (int) (2 + (Math.random() * (this.dim-2)));
			limit++;
		}while(!isOkayWall(randX, randY) && limit < LIMIT_WALL);
		
		//System.out.println(rand_x);
		//System.out.println(rand_y);
		
		if(limit == LIMIT_WALL) // trop de mur sur le plateau
		{
			return; 
		}
		
		int dir = (int) (1 + (Math.random() * (5-1)));		// On choisit la direction al�atoirement 
		
		//System.out.println(dir);
		
		int maxSize = 0;
		
		int maxX = randX;
		int maxY = randY;
		
		while(isOkayWall(maxX, maxY))
		{
			switch(dir)
			{
				case 1 : maxX++;
						break;
				case 2 : maxY++;
						break;
				case 3 : maxX--;
						break;
				case 4 : maxY--;
						break;
			}
			maxSize++;
		}
		
		int size;
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
		if(maxSize != 1)	// on choisit la taille au hasard entre la taille max /1.5 et la taille max
		{
			size = (int) (maxSize/1.5 + (Math.random() * (maxSize-maxSize/1.5)));
		}
		else
		{
			size = maxSize;
		}
		//System.out.println(max_x);
		//System.out.println(max_y);
		
		//System.out.println("direction : " + dir + " / x : " + rand_x + " / y : " + rand_y + " / size max : " + max_size + " / size : " + size);
		
		murs.add(new Wall(dir, size, randX, randY)); // Cr�ation du nouveau mur avec les variables trouv�s ci-dessus
	}
	
	/**
	 * V�rifie que le mur peut commencer � cet emplacement car il ne faut 
	 * pas que deux murs soient coll�s
	 * 
	 * @param 		xSearch	x � v�rfier
	 * @param 		ySearch	y � v�rifier
	 * @return 		boolean 	true si le mur est possible faux sinon
	 */
	public boolean isOkayWall(int xSearch, int ySearch)
	{
		for(int y = ySearch-1; y < ySearch+2; y++)
		{
			for(int x = xSearch-1; x < xSearch+2; x++)
			{
				int indice = (this.dim+2)*y + x;
				if(this.plateau.get(indice).toString() != ".")
				{
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * Synchronisation des murs avec le plateau. On place ces derniers
	 * sur le plateau en remplacant les cases "Free" pas des "Stone"
	 */
	public void syncWalls()
	{
		for(int i=0; i < murs.size(); i++)
		{
			for(int y = 0; y < murs.get(i).getSize(); y++)
			{
				plateau.remove(murs.get(i).getIndice(y, this.dim+2) );
				plateau.add(murs.get(i).getIndice(y, this.dim+2), murs.get(i).getCase(y));
			}
		}
	}
	
	/**
	 * On initialise le tr�sor � une place qui est possible car il faut 
	 * qu'il soit accessible
	 */
	public void initTreasure()
	{
		int randX;
		int randY;
		
		do{
			randX = (int) (1 + (Math.random() * (this.dim)));
			randY = (int) (1 + (Math.random() * (this.dim)));
		}while(plateau.get((this.dim+2)*randY + randX).toString() != ".");
		
		this.tresor = new Treasure(randX, randY);
		//System.out.println(" TRESOR : x :" + rand_x + " / y : " + rand_y );
	}
	
	/**
	 * Initialisation d'un chasseur, � des coordonn�es valides et al�atoires
	 */
	public void initHunters()
	{
		int randX;
		int randY;
		
		do{
			randX = (int) (1 + (Math.random() * (this.dim)));
			randY = (int) (1 + (Math.random() * (this.dim)));
		}while(plateau.get((this.dim+2)*randY + randX).toString() != "." || this.tresor.isTreasure(randX, randY));
		
		String str = "";
		
		if(joueurs.size() == 0)
		{
			str = "A";
			joueurs.add(new Hunter(randX, randY, str, this.tresor.getX(), this.tresor.getY()));
		}
		else
		{
			char nom = (char) ((int) joueurs.get(joueurs.size()-1).toString().charAt(0) + 1);
			str = "" + nom;
			joueurs.add(new Hunter(randX, randY, str, this.tresor.getX(), this.tresor.getY()));
		}
		//System.out.println(" HUNTER : x :" + rand_x + " / y : " + rand_y + " / nom : " + str + " / Position : " + ((this.dim+2)*rand_y + rand_x) + " / case d�ja pr�sent : " + plateau.get((this.dim+2)*rand_y + rand_x).to_String());
		hunterSync(); 
	}
	
	/**
	 * sychronisation des chasseurs sur le plateau
	 */
	public void hunterSync()
	{
		for(int i=0; i < joueurs.size(); i++)
		{
			plateau.remove(joueurs.get(i).getindice(this.dim+2) );
			plateau.add(joueurs.get(i).getindice(this.dim+2), new OccupiedByHunter(joueurs.get(i).getX(), joueurs.get(i).getY(), joueurs.get(i).toString()));
		}
	}
	
	/**
	 * On joue un tour. Si ce dernier se passe bien, la fonction
	 * retourne 0 et si un joueur gagne 1
	 * 
	 * @return 		int 	0 : tour suivant // 1 : gagnant
	 */
	public int playTurn()
	{
		int i;
		for(i = 0; i < joueurs.size(); i++)
		{
			int oldI = joueurs.get(i).getindice(this.dim+2);
			plateau.remove(oldI);
			plateau.add(oldI, new Free( joueurs.get(i).getX() , joueurs.get(i).getY() ));
			
			System.out.println("Personnage " + joueurs.get(i).toString());
			System.out.println("    Hunter [" + joueurs.get(i).getX() + " " + joueurs.get(i).getY() + "] dir " + joueurs.get(i).getDir());
			
			int next = joueurs.get(i).moveHunter(dim);
			plateau.get(next).process(joueurs.get(i));
			
			if(joueurs.get(i).getDir() == -1)
			{
				System.out.println("\nWINNER : HUNTER " + joueurs.get(i).toString() );
				return 1;
			}
			
			System.out.println("    Best dir " + joueurs.get(i).getDir());
			System.out.println("    -> Hunter [" + joueurs.get(i).getX() + " " + joueurs.get(i).getY() + "] dir " + joueurs.get(i).getDir() + "\n");
			
			int new_i = joueurs.get(i).getindice(this.dim+2);
			plateau.remove(new_i);
			plateau.add(new_i, new OccupiedByHunter(joueurs.get(i).getX(), joueurs.get(i).getY(), joueurs.get(i).toString()));
		}
		
		return 0;
		
	}
	
	/**
	 * Fonction toString qui affiche le plateau
	 * 
	 * @return 		String 		Plateau de jeu avec tous ces composants
	 */
	public String toString()
	{
		String str="";
		for(int y = 0; y < dim+2; y++)
		{
			for(int x = 0; x < dim+2; x++)
			{
				int indice = (this.dim+2)*y + x;
				if(this.tresor.isTreasure(x,y))
				{
					str += this.tresor.toString();
				}
				else
				{
					str += this.plateau.get(indice).toString();
				}
			}
			str += "\n";
		}
		return str;
	}
		
}


